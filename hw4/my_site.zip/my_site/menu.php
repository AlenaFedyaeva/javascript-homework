<div class="header">
			<a href="index.php"> Главная </a>
			<a href="puzzle.php"> Загадки </a>
			<a href="guess.html"> Угадайка </a>
			<a href="guess_multi.html"> Угадайка мультиплеер</a>
			<a href="gen_passwd.html"> Генератор паролей </a>
</div>
